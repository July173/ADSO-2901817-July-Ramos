import { API_BASE } from './api-base.js';
const CONTINENT_API = `${API_BASE}/continent`;

export const getContinents = async () => {
  const res = await fetch(CONTINENT_API);
  return res.json();
};

export const createContinent = async (data) => {
  const res = await fetch(CONTINENT_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteContinent = async (id) => {
  const res = await fetch(`${CONTINENT_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
