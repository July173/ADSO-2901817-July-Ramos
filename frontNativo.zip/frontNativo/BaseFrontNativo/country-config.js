import { API_BASE } from './api-base.js';
const COUNTRY_API = `${API_BASE}/country`;

export const getCountries = async () => {
  const res = await fetch(COUNTRY_API);
  return res.json();
};

export const createCountry = async (data) => {
  const res = await fetch(COUNTRY_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteCountry = async (id) => {
  const res = await fetch(`${COUNTRY_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
