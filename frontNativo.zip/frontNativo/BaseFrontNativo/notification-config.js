import { API_BASE } from './api-base.js';
const NOTIFICATION_API = `${API_BASE}/notification`;

export const getNotifications = async () => {
  const res = await fetch(NOTIFICATION_API);
  return res.json();
};

export const createNotification = async (data) => {
  const res = await fetch(NOTIFICATION_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteNotification = async (id) => {
  const res = await fetch(`${NOTIFICATION_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
