import { API_BASE } from './api-base.js';
const BOARDING_GATE_API = `${API_BASE}/boarding_gate`;

export const getBoardingGates = async () => {
  const res = await fetch(BOARDING_GATE_API);
  return res.json();
};

export const createBoardingGate = async (data) => {
  const res = await fetch(BOARDING_GATE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteBoardingGate = async (id) => {
  const res = await fetch(`${BOARDING_GATE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
