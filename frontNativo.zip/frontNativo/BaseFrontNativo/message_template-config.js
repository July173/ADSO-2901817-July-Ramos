import { API_BASE } from './api-base.js';
const MESSAGE_TEMPLATE_API = `${API_BASE}/message_template`;

export const getMessageTemplates = async () => {
  const res = await fetch(MESSAGE_TEMPLATE_API);
  return res.json();
};

export const createMessageTemplate = async (data) => {
  const res = await fetch(MESSAGE_TEMPLATE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteMessageTemplate = async (id) => {
  const res = await fetch(`${MESSAGE_TEMPLATE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
