import { API_BASE } from './api-base.js';
const FORM_API = `${API_BASE}/form`;

export const getForms = async () => {
  const res = await fetch(FORM_API);
  return res.json();
};

export const createForm = async (data) => {
  const res = await fetch(FORM_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteForm = async (id) => {
  const res = await fetch(`${FORM_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
