import { API_BASE } from './api-base.js';
const BAGGAGE_API = `${API_BASE}/baggage`;

export const getBaggages = async () => {
  const res = await fetch(BAGGAGE_API);
  return res.json();
};

export const createBaggage = async (data) => {
  const res = await fetch(BAGGAGE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteBaggage = async (id) => {
  const res = await fetch(`${BAGGAGE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
