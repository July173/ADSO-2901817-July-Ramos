import { API_BASE } from './api-base.js';
const FLIGHT_TYPE_API = `${API_BASE}/flight_type`;

export const getFlightTypes = async () => {
  const res = await fetch(FLIGHT_TYPE_API);
  return res.json();
};

export const createFlightType = async (data) => {
  const res = await fetch(FLIGHT_TYPE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteFlightType = async (id) => {
  const res = await fetch(`${FLIGHT_TYPE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
