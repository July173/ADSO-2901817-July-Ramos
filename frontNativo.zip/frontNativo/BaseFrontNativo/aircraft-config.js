import { API_BASE } from './api-base.js';
const AIRCRAFT_API = `${API_BASE}/aircraft`;

export const getAircrafts = async () => {
  const res = await fetch(AIRCRAFT_API);
  return res.json();
};

export const createAircraft = async (data) => {
  const res = await fetch(AIRCRAFT_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteAircraft = async (id) => {
  const res = await fetch(`${AIRCRAFT_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
