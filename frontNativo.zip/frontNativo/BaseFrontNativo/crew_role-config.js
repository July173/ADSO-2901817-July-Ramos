import { API_BASE } from './api-base.js';
const CREW_ROLE_API = `${API_BASE}/crew_role`;

export const getCrewRoles = async () => {
  const res = await fetch(CREW_ROLE_API);
  return res.json();
};

export const createCrewRole = async (data) => {
  const res = await fetch(CREW_ROLE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteCrewRole = async (id) => {
  const res = await fetch(`${CREW_ROLE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
