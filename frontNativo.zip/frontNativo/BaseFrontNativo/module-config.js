import { API_BASE } from './api-base.js';
const MODULE_API = `${API_BASE}/module`;

export const getModules = async () => {
  const res = await fetch(MODULE_API);
  return res.json();
};

export const createModule = async (data) => {
  const res = await fetch(MODULE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteModule = async (id) => {
  const res = await fetch(`${MODULE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
