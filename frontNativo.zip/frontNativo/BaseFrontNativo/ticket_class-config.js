import { API_BASE } from './api-base.js';
const TICKET_CLASS_API = `${API_BASE}/ticket_class`;

export const getTicketClasses = async () => {
  const res = await fetch(TICKET_CLASS_API);
  return res.json();
};

export const createTicketClass = async (data) => {
  const res = await fetch(TICKET_CLASS_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteTicketClass = async (id) => {
  const res = await fetch(`${TICKET_CLASS_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
