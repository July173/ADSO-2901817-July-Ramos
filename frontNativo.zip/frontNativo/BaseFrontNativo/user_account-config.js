import { API_BASE } from './api-base.js';
const USER_ACCOUNT_API = `${API_BASE}/user_account`;

export const getUserAccounts = async () => {
  const res = await fetch(USER_ACCOUNT_API);
  return res.json();
};

export const createUserAccount = async (data) => {
  const res = await fetch(USER_ACCOUNT_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteUserAccount = async (id) => {
  const res = await fetch(`${USER_ACCOUNT_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
