import { API_BASE } from './api-base.js';
const CITY_API = `${API_BASE}/city`;

export const getCities = async () => {
  const res = await fetch(CITY_API);
  return res.json();
};

export const createCity = async (data) => {
  const res = await fetch(CITY_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteCity = async (id) => {
  const res = await fetch(`${CITY_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
