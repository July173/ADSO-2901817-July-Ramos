import { API_BASE } from './api-base.js';
const PASSENGER_API = `${API_BASE}/passenger`;

export const getPassengers = async () => {
  const res = await fetch(PASSENGER_API);
  return res.json();
};

export const createPassenger = async (data) => {
  const res = await fetch(PASSENGER_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deletePassenger = async (id) => {
  const res = await fetch(`${PASSENGER_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
