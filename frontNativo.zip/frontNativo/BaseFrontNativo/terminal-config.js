import { API_BASE } from './api-base.js';
const TERMINAL_API = `${API_BASE}/terminal`;

export const getTerminals = async () => {
  const res = await fetch(TERMINAL_API);
  return res.json();
};

export const createTerminal = async (data) => {
  const res = await fetch(TERMINAL_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteTerminal = async (id) => {
  const res = await fetch(`${TERMINAL_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
