import { API_BASE } from './api-base.js';
const CREW_ASSIGNMENT_API = `${API_BASE}/crew_assignment`;

export const getCrewAssignments = async () => {
  const res = await fetch(CREW_ASSIGNMENT_API);
  return res.json();
};

export const createCrewAssignment = async (data) => {
  const res = await fetch(CREW_ASSIGNMENT_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteCrewAssignment = async (id) => {
  const res = await fetch(`${CREW_ASSIGNMENT_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
