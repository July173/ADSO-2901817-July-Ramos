import { API_BASE } from './api-base.js';
const DOCUMENT_TYPE_API = `${API_BASE}/document_type`;

export const getDocumentTypes = async () => {
  const res = await fetch(DOCUMENT_TYPE_API);
  return res.json();
};

export const createDocumentType = async (data) => {
  const res = await fetch(DOCUMENT_TYPE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteDocumentType = async (id) => {
  const res = await fetch(`${DOCUMENT_TYPE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
