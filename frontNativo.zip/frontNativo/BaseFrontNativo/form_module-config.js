import { API_BASE } from './api-base.js';
const FORM_MODULE_API = `${API_BASE}/form_module`;

export const getFormModules = async () => {
  const res = await fetch(FORM_MODULE_API);
  return res.json();
};

export const createFormModule = async (data) => {
  const res = await fetch(FORM_MODULE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteFormModule = async (id) => {
  const res = await fetch(`${FORM_MODULE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
