import { API_BASE } from './api-base.js';
const ROLE_FORM_API = `${API_BASE}/role_form`;

export const getRoleForms = async () => {
  const res = await fetch(ROLE_FORM_API);
  return res.json();
};

export const createRoleForm = async (data) => {
  const res = await fetch(ROLE_FORM_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteRoleForm = async (id) => {
  const res = await fetch(`${ROLE_FORM_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
