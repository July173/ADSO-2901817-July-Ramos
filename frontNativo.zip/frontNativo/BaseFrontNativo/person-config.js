import { API_BASE } from './api-base.js';
const PERSON_API = `${API_BASE}/person`;

export const getPersons = async () => {
  const res = await fetch(PERSON_API);
  return res.json();
};

export const createPerson = async (data) => {
  const res = await fetch(PERSON_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deletePerson = async (id) => {
  const res = await fetch(`${PERSON_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
