import { API_BASE } from './api-base.js';
const AIRCRAFT_TYPE_API = `${API_BASE}/aircraft_type`;

export const getAircraftTypes = async () => {
  const res = await fetch(AIRCRAFT_TYPE_API);
  return res.json();
};

export const createAircraftType = async (data) => {
  const res = await fetch(AIRCRAFT_TYPE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteAircraftType = async (id) => {
  const res = await fetch(`${AIRCRAFT_TYPE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
