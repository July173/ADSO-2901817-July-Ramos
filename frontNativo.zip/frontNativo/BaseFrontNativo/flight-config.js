import { API_BASE } from './api-base.js';
const FLIGHT_API = `${API_BASE}/flight`;

export const getFlights = async () => {
  const res = await fetch(FLIGHT_API);
  return res.json();
};

export const createFlight = async (data) => {
  const res = await fetch(FLIGHT_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteFlight = async (id) => {
  const res = await fetch(`${FLIGHT_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
