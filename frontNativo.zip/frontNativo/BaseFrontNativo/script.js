// Importar dinámicamente los módulos de configuración
const entityModules = {
  continent: 'continent-config.js',
  country: 'country-config.js',
  state: 'state-config.js',
  city: 'city-config.js',
  airport: 'airport-config.js',
  terminal: 'terminal-config.js',
  boarding_gate: 'boarding_gate-config.js',
  document_type: 'document_type-config.js',
  flight_type: 'flight_type-config.js',
  aircraft_type: 'aircraft_type-config.js',
  crew_role: 'crew_role-config.js',
  ticket_class: 'ticket_class-config.js',
  role: 'role-config.js',
  module: 'module-config.js',
  form: 'form-config.js',
  form_module: 'form_module-config.js',
  role_form: 'role_form-config.js',
  person: 'person-config.js',
  user_account: 'user_account-config.js',
  employee: 'employee-config.js',
  aircraft: 'aircraft-config.js',
  flight: 'flight-config.js',
  crew_assignment: 'crew_assignment-config.js',
  ticket: 'ticket-config.js',
  baggage: 'baggage-config.js',
};

const entityFields = {
  continent: ['id', 'code', 'name', 'description'],
  country: ['id', 'code', 'name', 'description', 'continent_id'],
  state: ['id', 'code', 'name', 'description', 'country_id'],
  city: ['id', 'code', 'name', 'description', 'state_id'],
  airport: ['id', 'code', 'name', 'address', 'city_id'],
  terminal: ['id', 'code', 'name', 'airport_id'],
  boarding_gate: ['id', 'code', 'name', 'terminal_id'],
  document_type: ['id', 'code', 'name', 'description'],
  flight_type: ['id', 'code', 'name', 'description'],
  aircraft_type: ['id', 'code', 'name', 'description'],
  crew_role: ['id', 'code', 'name', 'description'],
  ticket_class: ['id', 'code', 'name', 'description'],
  role: ['id', 'name', 'description'],
  module: ['id', 'name', 'color', 'icon', 'path'],
  form: ['id', 'name', 'color', 'icon', 'path', 'section'],
  form_module: ['id', 'form_id', 'module_id'],
  role_form: ['id', 'role_id', 'form_id'],
  person: ['id', 'first_name', 'last_name', 'document_number', 'birth_date', 'gender', 'phone', 'email', 'address', 'attendant_name', 'attending_phone', 'document_type_id', 'city_id'],
  user_account: ['id', 'username', 'password_hash', 'person_id', 'role_id'],
  employee: ['id', 'salary', 'hire_date', 'crew_role_id', 'person_id'],
  aircraft: ['id', 'manufacturer', 'registration_code', 'hours_in_use', 'aircraft_type_id'],
  flight: ['id', 'flight_date', 'departure_time', 'arrival_time', 'flight_type_id', 'origin_boarding_gate_id', 'destination_boarding_gate_id', 'aircraft_id'],
  crew_assignment: ['id', 'flight_id', 'employee_id', 'crew_role_id'],
  ticket: ['id', 'code', 'flight_id', 'passenger_id', 'ticket_class_id', 'seat_number', 'price'],
  baggage: ['id', 'code', 'weight', 'ticket_id'],
  passenger: ['id', 'frequent_flyer_number', 'person_id'],
  message_template: ['id', 'code', 'name', 'subject_template', 'body_template'],
  notification: ['id', 'person_id', 'channel', 'subject', 'message', 'sent_at', 'status'],
};

let currentEntity = 'continent';
let currentModule = null;

document.addEventListener('DOMContentLoaded', async () => {
  const selector = document.getElementById('entity-selector');
  selector.addEventListener('change', async (e) => {
    currentEntity = e.target.value;
    await loadEntityModule();
    renderTable();
  });
  await loadEntityModule();
  renderTable();
});

async function loadEntityModule() {
  const modulePath = entityModules[currentEntity];
  currentModule = await import(`./${modulePath}`);
}

async function renderTable() {
  if (!currentModule) return;
  const fields = entityFields[currentEntity];
  const headerRow = document.getElementById('table-header');
  headerRow.innerHTML = '';
  fields.forEach(f => {
    const th = document.createElement('th');
    th.className = 'px-4 py-2';
    th.textContent = f;
    headerRow.appendChild(th);
  });
  const thAcc = document.createElement('th');
  thAcc.className = 'px-4 py-2';
  thAcc.textContent = 'Acciones';
  headerRow.appendChild(thAcc);

  const tbody = document.getElementById('table-body');
  tbody.innerHTML = '';
  let items = [];
  try {
    items = await currentModule[`get${capitalize(currentEntity)}s`]();
  } catch (e) {
    tbody.innerHTML = '<tr><td colspan="'+(fields.length+1)+'">Error al cargar datos</td></tr>';
    return;
  }
  if (!Array.isArray(items)) items = [];
  items.forEach(item => {
    const tr = document.createElement('tr');
    fields.forEach(f => {
      const td = document.createElement('td');
      td.className = 'px-4 py-2';
      td.textContent = item[f] ?? '';
      tr.appendChild(td);
    });
    const tdAcc = document.createElement('td');
    tdAcc.className = 'px-4 py-2';
    tdAcc.innerHTML = `<button class='bg-red-600 text-white px-2 py-1 rounded' onclick='deleteRecord(${item.id})'>Eliminar</button>`;
    tr.appendChild(tdAcc);
    tbody.appendChild(tr);
  });
}

window.openForm = function() {
  const modal = document.getElementById('modal');
  const formFields = document.getElementById('form-fields');
  const fields = entityFields[currentEntity].filter(f => f !== 'id');
  formFields.innerHTML = '';
  fields.forEach(f => {
    formFields.innerHTML += `<div class='mb-2'><label class='block font-semibold mb-1'>${f}</label><input type='text' id='field-${f}' class='w-full px-2 py-1 border rounded'/></div>`;
  });
  document.getElementById('form-title').textContent = 'Nuevo ' + capitalize(currentEntity);
  modal.classList.remove('hidden');
}

window.closeForm = function() {
  document.getElementById('modal').classList.add('hidden');
}

window.submitForm = async function(e) {
  e.preventDefault();
  const fields = entityFields[currentEntity].filter(f => f !== 'id');
  const data = {};
  fields.forEach(f => {
    data[f] = document.getElementById('field-' + f).value;
  });
  try {
    await currentModule[`create${capitalize(currentEntity)}`](data);
    closeForm();
    renderTable();
  } catch (err) {
    alert('Error al guardar');
  }
}

window.deleteRecord = async function(id) {
  if (!confirm('¿Seguro que deseas eliminar este registro?')) return;
  try {
    await currentModule[`delete${capitalize(currentEntity)}`](id);
    renderTable();
  } catch (err) {
    alert('Error al eliminar');
  }
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
document.addEventListener("DOMContentLoaded", () => {
  loadTable();
});

// Cache para almacenar estudiantes y cursos
let studentsCache = [];
let coursesCache = [];

async function loadCaches() {
  try {
    // Cargar estudiantes
    const studentsRes = await fetch(API_STUDENT);
    studentsCache = await studentsRes.json();
    
    // Cargar cursos
    const coursesRes = await fetch(API_COURSE);
    coursesCache = await coursesRes.json();
  } catch (error) {
    console.error("Error loading caches:", error);
  }
}

async function loadTable() {
  try {
    // Cargar caches primero
    await loadCaches();
    
    const res = await fetch(API_STUDENT_COURSE);
    const data = await res.json();
    const tbody = document.getElementById("table-body");
    tbody.innerHTML = "";

    console.log("StudentCourse data:", data); // Para debugging

    for (const item of data) {
      // Buscar el nombre del estudiante
      const student = studentsCache.find(s => s.id === item.studentId);
      const studentName = student ? student.name : 'Sin nombre';
      
      // Buscar el nombre del curso
      const course = coursesCache.find(c => c.id === item.courseId);
      const courseName = course ? course.name : 'Sin curso';
      
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="px-4 py-2">${studentName}</td>
        <td class="px-4 py-2">${courseName}</td>
        <td class="px-4 py-2">
          <button onclick="editRecord(${item.id})" class="text-blue-600 hover:text-blue-800">Editar</button> |
          <button onclick="deleteHard(${item.id})" class="text-red-600 hover:text-red-800">Eliminar</button>
        </td>
      `;
      tbody.appendChild(tr);
    }
    
    // Mostrar estado vacío si no hay datos
    if (data.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td colspan="3" class="px-4 py-8 text-center text-gray-500">
          No hay inscripciones registradas
        </td>
      `;
      tbody.appendChild(tr);
    }
    
  } catch (error) {
    console.error("Error loading table:", error);
    const tbody = document.getElementById("table-body");
    tbody.innerHTML = `
      <tr>
        <td colspan="3" class="px-4 py-8 text-center text-red-500">
          Error al cargar los datos
        </td>
      </tr>
    `;
  }
}

async function buildForm() {
  const container = document.getElementById("form-fields");
  container.innerHTML = "";

  // Asegurarse de que los caches estén cargados
  if (studentsCache.length === 0 || coursesCache.length === 0) {
    await loadCaches();
  }

  for (const field of formFields) {
    const label = document.createElement("label");
    label.textContent = field.label;
    label.className = "block mb-1 mt-2 font-medium";

    if (field.type === "select") {
      const select = document.createElement("select");
      select.id = field.id;
      select.required = true;
      select.className = "w-full border border-gray-300 p-2 rounded mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500";
      
      try {
        // Add default option
        select.innerHTML = '<option value="">Seleccionar...</option>';
        
        let data;
        if (field.id === 'studentId') {
          data = studentsCache.filter(item => item.active !== false);
        } else if (field.id === 'courseId') {
          data = coursesCache.filter(item => item.active !== false);
        } else {
          // Fallback para otros campos select
          const res = await fetch(field.source);
          data = await res.json();
          data = data.filter(item => item.active !== false);
        }
        
        const options = data.map(item =>
          `<option value="${item.id}">${item[field.textField]}</option>`
        ).join("");
        
        select.innerHTML += options;
      } catch (error) {
        console.error(`Error loading ${field.label}:`, error);
        select.innerHTML = '<option value="">Error cargando datos</option>';
      }
      
      container.appendChild(label);
      container.appendChild(select);
    } else {
      const input = document.createElement("input");
      input.type = field.type;
      input.id = field.id;
      input.required = true;
      input.className = "w-full border border-gray-300 p-2 rounded mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500";
      container.appendChild(label);
      container.appendChild(input);
    }
  }
}

function openForm() {
  document.getElementById("modal").classList.remove("hidden");
  document.getElementById("form-title").textContent = "Nuevo Registro";
  document.getElementById("record-id").value = "";
  buildForm();
}

function closeForm() {
  document.getElementById("modal").classList.add("hidden");
}

async function submitForm(event) {
  event.preventDefault();
  const id = document.getElementById("record-id").value;
  const body = {};

  for (const field of formFields) {
    const element = document.getElementById(field.id);
    if (field.type === "select") {
      // Convert to number for foreign keys
      body[field.id] = parseInt(element.value);
    } else if (field.type === "number") {
      body[field.id] = parseInt(element.value);
    } else if (field.type === "checkbox") {
      body[field.id] = element.checked;
    } else {
      body[field.id] = element.value;
    }
  }

  // Validate required fields
  if (!body.studentId || !body.courseId) {
    alert("Por favor selecciona tanto el estudiante como el curso");
    return;
  }

  try {
    const method = id ? "PATCH" : "POST";
    const url = id ? `${API_STUDENT_COURSE}/update` : API_STUDENT_COURSE;

    const response = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(id ? { id: parseInt(id), ...body } : body)
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    closeForm();
    loadTable();
  } catch (error) {
    console.error("Error saving record:", error);
    alert("Error al guardar el registro. Por favor intenta de nuevo.");
  }
}

async function editRecord(id) {
  try {
    const res = await fetch(`${API_STUDENT_COURSE}/${id}`);
    if (!res.ok) {
      throw new Error(`HTTP error! status: ${res.status}`);
    }
    
    const item = await res.json();
    console.log("Edit record data:", item); // Para debugging

    document.getElementById("record-id").value = item.id;
    await buildForm();

    // Set form values
    formFields.forEach(f => {
      const element = document.getElementById(f.id);
      if (element) {
        if (f.type === "checkbox") {
          element.checked = item[f.id];
        } else {
          element.value = item[f.id] || "";
        }
      }
    });

    document.getElementById("form-title").textContent = "Editar Registro";
    document.getElementById("modal").classList.remove("hidden");
  } catch (error) {
    console.error("Error loading record for edit:", error);
    alert("Error al cargar el registro para editar.");
  }
}

async function deleteHard(id) {
  if (confirm("¿Eliminar permanentemente este registro?")) {
    try {
      const response = await fetch(`${API_STUDENT_COURSE}/${id}`, { 
        method: "DELETE" 
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      loadTable();
    } catch (error) {
      console.error("Error deleting record:", error);
      alert("Error al eliminar el registro.");
    }
  }
}