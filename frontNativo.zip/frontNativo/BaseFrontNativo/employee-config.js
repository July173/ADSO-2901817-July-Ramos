import { API_BASE } from './api-base.js';
const EMPLOYEE_API = `${API_BASE}/employee`;

export const getEmployees = async () => {
  const res = await fetch(EMPLOYEE_API);
  return res.json();
};

export const createEmployee = async (data) => {
  const res = await fetch(EMPLOYEE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteEmployee = async (id) => {
  const res = await fetch(`${EMPLOYEE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
