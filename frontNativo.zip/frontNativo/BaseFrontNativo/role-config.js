import { API_BASE } from './api-base.js';
const ROLE_API = `${API_BASE}/role`;

export const getRoles = async () => {
  const res = await fetch(ROLE_API);
  return res.json();
};

export const createRole = async (data) => {
  const res = await fetch(ROLE_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteRole = async (id) => {
  const res = await fetch(`${ROLE_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
