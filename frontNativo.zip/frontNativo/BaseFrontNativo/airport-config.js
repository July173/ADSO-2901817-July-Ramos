import { API_BASE } from './api-base.js';
const AIRPORT_API = `${API_BASE}/airport`;

export const getAirports = async () => {
  const res = await fetch(AIRPORT_API);
  return res.json();
};

export const createAirport = async (data) => {
  const res = await fetch(AIRPORT_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteAirport = async (id) => {
  const res = await fetch(`${AIRPORT_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
