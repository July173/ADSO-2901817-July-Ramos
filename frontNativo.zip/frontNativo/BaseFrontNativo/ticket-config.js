import { API_BASE } from './api-base.js';
const TICKET_API = `${API_BASE}/ticket`;

export const getTickets = async () => {
  const res = await fetch(TICKET_API);
  return res.json();
};

export const createTicket = async (data) => {
  const res = await fetch(TICKET_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
};

export const deleteTicket = async (id) => {
  const res = await fetch(`${TICKET_API}/${id}`, {
    method: 'DELETE',
  });
  return res.json();
};
